package edu.miu.eregistrarmvc.service;

import edu.miu.eregistrarmvc.model.Role;

import java.util.Collection;

public interface UserRoleService {
    Collection<Role> saveAllUserRoles(Collection<Role> roles);

    Role saveUserRole(Role role);
}
